from sys import stdin
from random import randint
from termcolor import colored
from requests import Session
from argparse import ArgumentParser
from requests.exceptions import ConnectionError, Timeout

from lib.Globals import Color
from lib.PathFunctions import ender

s = Session()
def banner():
    b = '\x1b[5m\x1b[1m\x1b[40m\x1b[31m   __________  __    _______ \n  / ____/ __ \\/ /   / ____(_)\n / /   / /_/ / /   / /_  / / \n/ /___/ _, _/ /___/ __/ / /  \n\\____/_/ |_/_____/_/   /_/   \n                             \n\x1b[0m'
    print(b)
    print(colored('Intelligent CRLFi Hunter', color='red', attrs=['bold']))
    exit()

def starter(argv):
    if argv.banner:
        banner()
    if argv.output_directory:
        if not argv.domain:
            print("{} Output directory specified but not domain".format(Color.bad))
            exit()
    if not argv.wordlist:
        if not argv.domain:
            if not argv.stdin:
                print("{} Use --help".format(Color.bad))
                exit()
            else:
                return (line.rstrip('\n') for line in stdin.read().split('\n') if line)
        else:
            return [argv.domain.strip(' ')]
    else:
        return (line.rstrip('\n') for line in open(argv.wordlist) if line)

def return_iowrapper(filename = None, filepath = None):
    if filepath:
        f = open(f"{ender(filepath, '/')}{filename}{'.CRLFi'}", 'a')
    elif filename:
        f = open(filename, 'a')
    return f

def write_output(f, single_line):
    unit_payload, is_exploitable = single_line
    f.write(f"Payload:{unit_payload}, Exploitable:{is_exploitable}\n")
    if is_exploitable:
        print(f"{Color.good} Yes, the url is exploitable\t,Payload: {unit_payload}")

def deliver_request(url):
    try:
        response = s.get(url, timeout=5)
    except (ConnectionError,Timeout):
        return url, False
    except Exception as E:
        print(f"{Color.bad} Skipping {colored(url, color='cyan')} due to {E}")
        return url, False
    try:
        print(f"{Color.good} Response header: {response.headers['someheader']}")
        return url, True
    except:
        pass
    if response.history:
        response = response.history[0]
    try:
        print(f"{Color.good} Response header: {response.headers['someheader']}")
        return url, True
    except:
            return url, False

def send_payload(url: str) -> tuple:
    isReturnable = False
    url, exploitable, isReturnable  = deliver_request(url)
    if isReturnable:
        return url, exploitable
    instantiated_url = url.replace('http://', 'https://')
    url, exploitable, isReturnable = deliver_request(instantiated_url)
    if isReturnable:
        return instantiated_url, exploitable 
    instantiated_url = url.replace('http://', 'http://www.')
    url, exploitable, isReturnable = deliver_request(instantiated_url)
    return instantiated_url, exploitable

def parse_args():
    parser = ArgumentParser(description=colored("CRLFi Scanner", color='yellow'), epilog=colored("Enjoy bug hunting", color='yellow'))
    input_group = parser.add_mutually_exclusive_group()
    output_group = parser.add_mutually_exclusive_group()
    input_group.add_argument('---', '---', action="store_true", dest="stdin", help="Stdin")
    input_group.add_argument('-w', '--wordlist', type=str, help="Wordlist")
    parser.add_argument('-d', '--domain', type=str, help="Domain name")
    output_group.add_argument('-o', '--output', type=str, help="Output file")
    output_group.add_argument('-oD', '--output-directory', type=str, help="Output directory")
    parser.add_argument('-t', '--threads', type=int, help="Number of threads")
    parser.add_argument('-b', '--banner', action="store_true", help="Print banner and exit")
    return parser.parse_args()


